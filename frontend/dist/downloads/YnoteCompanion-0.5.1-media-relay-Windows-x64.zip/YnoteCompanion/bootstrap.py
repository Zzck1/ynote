import atexit,hashlib,json,os,shutil,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
os.environ['YNOTE_PROXY_DNS_VERIFY']='1'
# Do not download or enable any local ASR model.
archive=root/'assets'/'media-tools-publisher.zip'
if archive.is_file():
    from companion.server import app_root
    manifest=json.loads((root/'companion'/'tools.lock.json').read_text('utf-8'))
    with archive.open('rb') as f:valid=archive.stat().st_size==manifest['bytes'] and hashlib.file_digest(f,'sha256').hexdigest()==manifest['sha256']
    if not valid:raise RuntimeError('Bundled media component checksum mismatch')
    target=app_root()/'tools'/'download.zip.part'
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists() or target.stat().st_size!=manifest['bytes']:shutil.copyfile(archive,target)
from companion.entry import main
raise SystemExit(main())
